<?php include 'head.php';?>
<!-- ======= Header ======= -->
 
    
    <?php include 'top-menu.php';?>
    <!-- .navbar --> 
  
<!-- End Header -->
<main id="hero" class="bg-white">
  <section class="mamber-card">
    <div class="container search-box">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-title">
            <p>Change Password</p>
          </div>
          <form id="" name="" method="post" action="checkout-search.php" class="custom-search-from" enctype="application/x-www-form-urlencoded">
  <div class="row">
    <div class="form-group col-md-4">
      <label class="w-100 mb-2">Current Password</label>
      <input type="password" class="form-control" id="" name="" placeholder="Current Password" value="">
    </div>
    <div class="form-group col-md-4">
      <label class="w-100 mb-2">New Password</label>
      <input type="text" class="form-control" id="" name="" placeholder="New Password">
    </div>
    <div class="form-group col-md-4">
      <label class="w-100 mb-2">Confirm Password</label>
      <input type="text" class="form-control" id="" name="" placeholder="Confirm Password">
    </div>
    <div class="clearfix"></div>
    <div class="form-group col-lg-12 text-center mt-3">
      <button type="submit" id="submit" name="submit" class="btn btn-red btn-sm"  role="button" aria-disabled="false">Submit</button>
    </div>
    <div class=clearfix></div>
  </div>
</form>

        </div>
      </div>
    </div>
  </section>
</main>

<!-- ======= Footer ======= -->
<?php include 'footer.php';?>
</body>
</html>