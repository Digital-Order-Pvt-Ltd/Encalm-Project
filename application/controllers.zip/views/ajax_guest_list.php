<form id="g_addguestform" name="" method="post" action="<?=base_url('user/addguest')?>" class="custom-search-from pt-3" enctype="application/x-www-form-urlencoded">
          <div class="row">
		  
            <div class="form-group col-md-2">
              <label for="" class="d-none">Title*</label>
              <span class="caret"></span>
              <select id="g_title" name="g_title" class="form-control d-inline-block w-75 float-end">
                <option value="" selected="selected">Title*</option>
                <option value="Mr.">Mr.</option>
                <option value="Mrs.">Mrs.</option>
                <option value="Ms.">Ms.</option>
              </select>
            </div>
            <div class="form-group col-md-2">
              <label for="" class="d-none">First Name</label>
              <input type="text" class="form-control" id="g_first_name" name="g_first_name" placeholder="First Name" />
            </div>
            <div class="form-group col-md-2">
              <label for="" class="d-none">Last Name</label>
              <input type="text" class="form-control" id="g_last_name" name="g_last_name" placeholder="Last Name">
            </div>
            <div class="form-group col-md-2">
              <label for="" class="d-none">Date Of Birth</label>
              <input type="text" class="form-control datepicker" id="g_dob" name="g_dob" placeholder="Date Of Birth">
            </div>
            <div class="form-group col-md-3">
              <label for="" class="d-none">Passport/Govt</label>
              <input type="text" class="form-control" id="g_passport_no" name="g_passport_no" placeholder="Passport/Govt ID">
            </div>
            <div class="form-group col-lg-1 text-center">
              <button type="button"  name="submit" class="btn btn-primary btn-sm small closeBTN float-end px-3" id="add_guests" onclick="save_guest_details('<?=base_url('user/addguest');?>')">+ ADD</button>
            </div>
</form>
<?php  for($i=1;$i<6;$i++){ ?>
<div class="clearfix mb-3"></div>
<div class="form-group col-md-2">
  <div class="form-check d-inline-block p-0">
	<input type="checkbox" class="form-check-input mx-auto mt-2 noofcheckbox" id="checked_id_<?=$i?>" onclick="AddGuestCheck(<?=$i?>)">
	 
  </div>
  <label for="" class="d-none">Title</label>
  <span class="caret"></span>
  <select id="" name="" class="form-control d-inline-block w-75 float-end" disabled>
	<option value="">Title</option>
	<option value="mr" selected="selected">Mr.</option>
	<option value="mrs">Mrs.</option>
	<option value="ms">Ms.</option>
  </select>
</div>
<div class="form-group col-md-2">
  <label for="" class="d-none">First Name</label>
  <input type="text" class="form-control" id="" name="" placeholder="First Name" value="Rohit" readonly>
</div>
<div class="form-group col-md-2">
  <label for="" class="d-none">Last Name</label>
  <input type="text" class="form-control" id="" name="" placeholder="Last Name" value="Sharma" readonly>
</div>
<div class="form-group col-md-2">
  <label for="" class="d-none">Date Of Birth</label>
  <input type="text" class="form-control datepicker" id="" name="" placeholder="Date Of Birth" value="25-Nov-1983" readonly>
</div>
<div class="form-group col-md-3">
  <label for="" class="d-none">Passport/Govt</label>
  <input type="text" class="form-control" id="" name="" placeholder="Passport/Govt ID" value="IN2562356" readonly>
</div>
<div class="form-group col-lg-1 text-center">
  <button type="submit" id="submit" name="submit" class="btn btn-primary btn-sm small closeBTN float-end px-3"  role="button" aria-disabled="false">+ EDIT</button>
</div>
<div class="clearfix mb-3"></div>
 <?php  } ?>
<div class="clearfix mb-3"></div>
<div class="form-group col-lg-12 text-center mt-3">
  <button type="submit" id="submit" name="submit" class="btn btn-primary small closeBTN float-end"  role="button" aria-disabled="false">Select</button>
</div>

<script>
function AddGuestCheck(id)
{
	var adult = "<?=!empty($this->session->userdata('s_adult'))?$this->session->userdata('s_adult'):0?>";
	var child = "<?=!empty($this->session->userdata('s_child'))?$this->session->userdata('s_child'):0?>";
 let x = parseInt(adult)+parseInt(child);
 
 
 
 if($("#iamguest").prop("checked") == true){
	   x = x-1;
 }
  
 let len = $('.noofcheckbox').filter(':checked').length;
if (len > x)
	{
		alert("sorry only select "+ x +" guest.");
		$('#checked_id_'+id).prop('checked', false); 
		 
	}
	else
	{
	}		
}
</script>